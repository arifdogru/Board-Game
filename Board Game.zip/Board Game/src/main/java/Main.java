/**
 * Created by Arif on 29.04.2017.
 */
public class Main {
    public static void main(String []args){
        Game game = new Game();
        game.displayBoard();
        game.play();
        game.displayBoard();
    }
}
